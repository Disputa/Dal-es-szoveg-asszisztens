import { emit, listen } from "@tauri-apps/api/event";

const els = {
  songTitle: document.getElementById("songTitle"),
  role: document.getElementById("role"),
  overlay: document.getElementById("overlay"),
  showList: document.getElementById("showList"),
  contentWrap: document.getElementById("contentWrap"),
  content: document.getElementById("content"),
};

const runtime = {
  frameId: null,
  isPlaying: false,
  scrollPos: 0,
  contentKey: "",
  mode: "blocks",
  speed: 100,
};

function clearScrollAnimation() {
  if (runtime.frameId) {
    cancelAnimationFrame(runtime.frameId);
    runtime.frameId = null;
  }
}

function setOverlay(text) {
  els.overlay.textContent = text || "";
  els.overlay.style.opacity = text ? "1" : "0";
  if (text) {
    setTimeout(() => {
      els.overlay.style.opacity = "0";
    }, 900);
  }
}

function renderShowList(titles = [], currentIndex = 0, visible = false) {
  els.showList.style.display = visible ? "block" : "none";
  els.contentWrap.style.left = visible ? "408px" : "24px";

  if (!visible) return;

  els.showList.innerHTML = titles
    .map((title, index) => `
      <button class="display-show-item ${index === currentIndex ? "active" : ""}" data-index="${index}">
        ${index + 1}. ${escapeHtml(title || "")}
      </button>
    `)
    .join("");

  els.showList.querySelectorAll(".display-show-item").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const idx = Number(btn.dataset.index);
      if (!Number.isInteger(idx)) return;
      await emit("display:select-item", { index: idx });
    });
  });
}

function normalizeFullTextForDisplay(text) {
  return String(text || "")
    .split(/\n{2,}/)
    .map((part) => part.trim())
    .filter(Boolean)
    .join("\n\n────────────\n\n");
}

function updateTransform() {
  els.content.style.transform = `translateY(${-runtime.scrollPos}px)`;
}

function startScroll(direction = "up") {
  clearScrollAnimation();

  const maxScroll = Math.max(0, els.content.scrollHeight - els.contentWrap.clientHeight);
  if (maxScroll <= 0) return;

  const pxPerFrame = Math.max(0.18, runtime.speed / 120);

  function tick() {
    if (!runtime.isPlaying) return;

    if (direction === "down") {
      runtime.scrollPos -= pxPerFrame;
      if (runtime.scrollPos < 0) runtime.scrollPos = 0;
    } else {
      runtime.scrollPos += pxPerFrame;
      if (runtime.scrollPos > maxScroll) runtime.scrollPos = maxScroll;
    }

    updateTransform();

    const canContinue =
      (direction === "down" && runtime.scrollPos > 0) ||
      (direction !== "down" && runtime.scrollPos < maxScroll);

    if (canContinue) {
      runtime.frameId = requestAnimationFrame(tick);
    }
  }

  runtime.frameId = requestAnimationFrame(tick);
}

function renderState(payload) {
  const {
    songTitle,
    role,
    text,
    fullText,
    mode,
    black,
    speed,
    isPlaying,
    showListVisible,
    showListTitles,
    currentItemIndex,
  } = payload;

  runtime.mode = mode || "blocks";
  runtime.speed = Number(speed) || 100;
  runtime.isPlaying = !!isPlaying;

  els.songTitle.textContent = songTitle || "";
  els.role.textContent = runtime.mode === "blocks" ? (role || "") : "";

  renderShowList(showListTitles || [], currentItemIndex || 0, !!showListVisible);

  clearScrollAnimation();

  if (black) {
    els.content.textContent = "";
    runtime.scrollPos = 0;
    updateTransform();
    return;
  }

  if (runtime.mode === "blocks") {
    runtime.contentKey = `block:${songTitle || ""}:${role || ""}:${text || ""}`;
    els.content.textContent = text || "";
    runtime.scrollPos = 0;
    updateTransform();
    return;
  }

  const displayText = normalizeFullTextForDisplay(fullText || text || "");
  const nextKey = `scroll:${songTitle || ""}:${displayText}`;
  if (runtime.contentKey !== nextKey) {
    runtime.scrollPos = runtime.mode === "scroll-down" ? 999999 : 0;
    runtime.contentKey = nextKey;
  }

  els.content.textContent = displayText;

  const maxScroll = Math.max(0, els.content.scrollHeight - els.contentWrap.clientHeight);
  if (runtime.mode === "scroll-down" && runtime.scrollPos > maxScroll) {
    runtime.scrollPos = maxScroll;
  }
  if (runtime.mode === "scroll-up" && runtime.scrollPos < 0) {
    runtime.scrollPos = 0;
  }

  updateTransform();

  if (runtime.isPlaying) {
    startScroll(runtime.mode === "scroll-down" ? "down" : "up");
  }
}

function escapeHtml(value) {
  return String(value || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

listen("display:block", (event) => {
  renderState(event.payload || {});
});

listen("display:overlay", (event) => {
  setOverlay(event.payload?.text || "");
});
