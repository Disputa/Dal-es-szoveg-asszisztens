EmlékSúgó_V2_working_fixed

Alap: EmlékSúgó_0.1.4_FIX_dist.

Változások:
- Display2 jobb oldali blokk-preview kattintás után a lejátszás nem áll meg; megtartja a korábbi PLAY/PAUSE állapotot.
- Scroll lejátszás közben a Display2 visszajelzi az aktuálisan látható blokkot.
- Az 1. kijelző kezelőfelületén a blokkok aktív kijelölése automatikusan követi a Display2-n futó blokkot.
- A főképernyős automatikus követés nem küld vissza új Display2 parancsot, ezért nem rángatja meg a futó szöveget.

Ellenőrzés:
- JS syntax check main/display: elvégzendő build előtt.
- ZIP integrity: elvégzendő csomagolás után.
