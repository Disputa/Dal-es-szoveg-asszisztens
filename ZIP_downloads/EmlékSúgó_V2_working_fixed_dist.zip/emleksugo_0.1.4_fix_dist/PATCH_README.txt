EmlékSúgó 0.1.2 FIXED – 0.1.1 alapján

Alap: visszanyert, működő 0.1.1 frontend/dist.

Beépített javítások:
- megmaradt a 0.1.1 színes megszólaló-név logikája;
- megmaradt a 0.1.1 helyes Display2 pozíciólogikája;
- megmaradt a nyitókép használata;
- alap lejátszási sebesség: 50%;
- Display2 szövegméret csúszka;
- megszólaló név méret csúszka;
- megszólaló név függőleges pozíció csúszka;
- ezek a beállítások projektmentésbe is bekerülnek;
- blokkos módban az utolsó blokk után automatikusan a következő dal elejére áll, és PAUSE-ban vár;
- scroll módban a scroll végén automatikusan a következő dal elejére áll, és PAUSE-ban vár;
- Display2 HUD halvány, egérmozgásra/ráhúzásra teljesen látható;
- Enter/Space nem indítja el a lejátszást szövegmező szerkesztése közben – az eredeti 0.1.1 védelme megmaradt.

Fontos: ez frontend/dist csomag. Telepítő vagy új Tauri exe készítéséhez ezt a distet kell a Tauri buildbe beágyazni.
