EmlékSúgó 0.1.3 FIX

Alap: 0.1.2_FIXED, amely a visszanyert, működő 0.1.1 frontendből készült.

Új elemek:
- Műsorrend drag&drop rendezése a bal oldali listában.
- Műsorrend TXT formátumú szerkesztése.
- Új, külön dalszöveg beszúrása a műsorrendbe.
- Aktuális műsorszám cím/idő szerkesztése.
- Aktuális műsorszám fel/le mozgatása és törlése.
- Főablak jobb felső sarok: elrejtés/tálcára, ablak/teljes képernyő, bezárás.

Szándékosan érintetlenül hagyva:
- Display2 alap működés, színezett megszólaló-nevek, nyitókép, blokkszerkesztő, sebesség és Display2 méret/pozíció beállítások.
