EmlékSúgó V2 working fixed - STOP_AT_END patch

Alap: EmlékSúgó_V2_working_fixed_ESP_ICON_dist.zip

Módosítás:
- Az utolsó szövegblokk után a program nem ugrik automatikusan a következő dalra.
- Blokkos módban az utolsó blokk időzített lejárta után PAUSE állapotban az utolsó blokkon marad.
- Scroll módban a Display2 a scroll végén helyben megáll, nem küld automatikus dalváltást.
- A kézi vezérlés megmaradt:
  - Következő dal gomb / PageDown továbbra is dalra ugrik.
  - Display2 dal/műsorrend kattintás továbbra is másik dalra ugrik.
  - Display2 jobb oldali blokk-preview kattintás továbbra is az adott blokkra ugrik.
  - Főképernyős blokk kattintás továbbra is az adott blokkot küldi.

Ellenőrzés:
- main-D235LGMW.js: node --check rendben
- display-DMyfn4Nc.js: node --check rendben
- ZIP integrity: tesztelve
