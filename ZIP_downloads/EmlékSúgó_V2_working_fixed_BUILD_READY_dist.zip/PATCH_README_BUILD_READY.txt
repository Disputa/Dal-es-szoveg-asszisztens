EmlékSúgó V2 working fixed – BUILD_READY csomag

Javított hibák:
1) Nyitókép indításkor:
   - A főképernyő splash már nem /assets abszolút útra hivatkozik, hanem relatív buildbiztos útra.
   - A nyitókép HTML inline fallbacket, CSS fallbacket és JS fallbacket is kapott.
   - Display2 induló háttere is megkapta a nyitóképet.

2) Projekt mentése:
   - A „Projekt mentése” nem ment többé csendben a Letöltések mappába.
   - Natív Save As dialógust kér.
   - .esp alapértelmezett kiterjesztés, JSON tartalommal.
   - Ha a buildből hiányzik a dialog/fs plugin vagy jogosultság, hibaüzenetet ad, és NEM ment automatikusan rossz helyre.

3) Bezárás / tálcára / ablak gombok:
   - A frontend hívásai megmaradtak.
   - A működéshez a src-tauri/capabilities/default.json adja meg a hiányzó core:window engedélyeket.

4) Telepítő/app neve:
   - src-tauri/tauri.conf.patch.json javasolt productName: "EmlékSúgó 2.0_FIX"
   - version: "2.0.0" (Tauri/semver miatt az aláhúzás nem verziószámba való)
   - így a telepítő neve nem 0.1.1-ként fog kijönni, ha a valós tauri.conf.json-ba átvezeted.

5) Ikon:
   - A csomag most már tartalmaz src-tauri/icons mappát is, nem csak build_assets/icons-t.
   - Ezeket a buildelő projekt src-tauri/icons mappájába kell másolni/cserélni.
   - tauri.conf.json bundle.icon mezőben ezekre kell hivatkozni.

KÖTELEZŐ BUILD LÉPÉSEK:
A) A dist tartalmát másold a frontendDist-ként használt dist mappába.
B) A src-tauri/icons tartalmát másold a projekt src-tauri/icons mappájába.
C) A src-tauri/capabilities/default.json-t másold / cseréld a projekt src-tauri/capabilities/default.json fájljára.
D) A src-tauri/tauri.conf.patch.json értékeit vezesd át a tényleges src-tauri/tauri.conf.json-ba.
E) Cargo.toml-ba legyen benne:
   tauri-plugin-dialog = "2"
   tauri-plugin-fs = "2"
F) src-tauri/src/lib.rs-ben legyen regisztrálva:
   .plugin(tauri_plugin_dialog::init())
   .plugin(tauri_plugin_fs::init())

Megjegyzés: a meglévő V2 logikákhoz nem nyúltam: Display2 preview-diák, végén megállás, blokk-követés, színezés, kézi dal/blokk ugrás marad.
