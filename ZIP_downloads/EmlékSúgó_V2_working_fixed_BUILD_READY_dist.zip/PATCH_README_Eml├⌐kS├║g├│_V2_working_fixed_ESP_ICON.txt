EmlékSúgó_V2_working_fixed – ESP + ikon patch

1) Projektmentés:
- A „Projekt mentése” gomb most .esp kiterjesztésű EmlékSúgóProjekt fájlt ment.
- A fájl tartalma továbbra is JSON, tehát ha valaki .json-ra átnevezi, visszaolvasható marad.
- A „Projekt megnyitása” input elfogadja: .esp, .json, .emleksugo.project.json.
- Ha a Tauri buildben nincs engedélyezve a dialog/fs plugin, a mentés biztonsági fallbackként letöltésként történik.

2) Ikon:
- A csomagban van build_assets/icons/app-icon.png és icon.ico.
- Ezeket build előtt a src-tauri/icons mappába kell bekötni/generálni.
- A tálcaikon, az EXE ikon, az MSI shortcut és az asztali indító ikon csak Tauri build/installer szinten állítható, a sima dist csomagból nem.

3) Buildhez szükséges:
- tauri-plugin-dialog
- tauri-plugin-fs
- capability fájl a mentési jogokhoz
- tauri.conf.json bundle.icon beállítás

A működő 0.1.4/V2 viselkedésekhez nem nyúltam hozzá: Display2, preview-dia, blokkkövetés, színek, nyitókép maradt.
