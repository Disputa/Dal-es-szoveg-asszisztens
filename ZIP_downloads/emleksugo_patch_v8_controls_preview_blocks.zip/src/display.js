
import { emit, listen } from "@tauri-apps/api/event";

const els = {
  songTitle: document.getElementById("songTitle"),
  role: document.getElementById("role"),
  overlay: document.getElementById("overlay"),
  showList: document.getElementById("showList"),
  contentWrap: document.getElementById("contentWrap"),
  content: document.getElementById("content"),
  transportHud: document.getElementById("transportHud"),
};

const runtime = {
  frameId: null,
  isPlaying: false,
  scrollPos: 0,
  contentKey: "",
  mode: "blocks",
  speed: 100,
  blocks: [],
  activeRole: "",
  blockIndex: 1,
  blockCount: 1,
};

const ROLE_COLORS = {
  "dosa": "#ffd166",
  "molnar": "#7dd3fc",
  "barabas": "#ff7aa2",
  "lorincz": "#c084fc",
  "egyutt": "#7ee081",
  "tutti": "#7ee081",
  "kozos": "#7ee081",
};

function normalizeRoleKey(value) {
  return String(value || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9+]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function resolveRoleColor(role) {
  const normalized = normalizeRoleKey(role);
  if (!normalized) return "#ffffff";

  if (normalized.includes("egyutt") || normalized.includes("tutti") || normalized.includes("kozos")) {
    return ROLE_COLORS.egyutt;
  }
  if (normalized.includes("+")) {
    const parts = normalized.split("+").map((part) => part.trim()).filter(Boolean);
    if (parts.length) {
      const firstKnown = parts.find((part) => ROLE_COLORS[part]);
      if (firstKnown) return ROLE_COLORS[firstKnown];
    }
    return "#f9d56e";
  }
  for (const [key, color] of Object.entries(ROLE_COLORS)) {
    if (normalized.includes(key)) return color;
  }
  return "#f4f0b5";
}

function applyRoleAppearance(element, role) {
  if (!element) return;
  element.textContent = role || "";
  element.style.color = resolveRoleColor(role);
}

function clearScrollAnimation() {
  if (runtime.frameId) {
    cancelAnimationFrame(runtime.frameId);
    runtime.frameId = null;
  }
}

function setOverlay(text) {
  els.overlay.textContent = text || "";
  els.overlay.style.opacity = text ? "1" : "0";
  if (text) {
    setTimeout(() => {
      els.overlay.style.opacity = "0";
    }, 900);
  }
}

function renderShowList(titles = [], currentIndex = 0, visible = false) {
  els.showList.style.display = visible ? "block" : "none";
  els.contentWrap.classList.toggle("with-list", visible);
  els.contentWrap.classList.toggle("without-list", !visible);

  if (!visible) return;

  els.showList.innerHTML = titles
    .map((title, index) => `
      <button class="display-show-item ${index === currentIndex ? "active" : ""}" data-index="${index}">
        ${index + 1}. ${escapeHtml(title || "")}
      </button>
    `)
    .join("");

  els.showList.querySelectorAll(".display-show-item").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const idx = Number(btn.dataset.index);
      if (!Number.isInteger(idx)) return;
      await emit("display:select-item", { index: idx });
    });
  });
}

function updateTransform() {
  els.content.style.transform = `translateY(${-runtime.scrollPos}px)`;
}

function updateRoleFromScroll() {
  if (!Array.isArray(runtime.blocks) || !runtime.blocks.length) {
    applyRoleAppearance(els.role, "");
    return;
  }

  const sections = Array.from(els.content.querySelectorAll(".scroll-block"));
  if (!sections.length) {
    applyRoleAppearance(els.role, runtime.activeRole || "");
    return;
  }

  const marker = runtime.scrollPos + els.contentWrap.clientHeight * 0.5;
  let activeIndex = 0;
  for (let i = 0; i < sections.length; i += 1) {
    if (sections[i].offsetTop <= marker) activeIndex = i;
  }

  runtime.activeRole = runtime.blocks[activeIndex]?.role || "";
  applyRoleAppearance(els.role, runtime.activeRole);
}

function renderScrollBlocks(blocks) {
  els.content.innerHTML = blocks
    .map((block, index) => `
      <section class="scroll-block" data-index="${index}">
        <div class="scroll-text">${escapeHtml(block.text || "")}</div>
      </section>
    `)
    .join('<div class="separator"></div>');
}

function setScrollPosForBlock(blockIndexZeroBased) {
  const sections = Array.from(els.content.querySelectorAll(".scroll-block"));
  const target = sections[blockIndexZeroBased];
  if (!target) return;

  const viewportHeight = els.contentWrap.clientHeight;
  const maxScroll = Math.max(0, els.content.scrollHeight - viewportHeight);
  const desired = Math.max(0, target.offsetTop - viewportHeight * 0.34);
  runtime.scrollPos = Math.min(maxScroll, desired);
  updateTransform();
  updateRoleFromScroll();
}

function startScroll(direction = "up") {
  clearScrollAnimation();

  const maxScroll = Math.max(0, els.content.scrollHeight - els.contentWrap.clientHeight);
  if (maxScroll <= 0) return;

  const pxPerFrame = Math.max(0.18, runtime.speed / 120);

  function tick() {
    if (!runtime.isPlaying) return;

    if (direction === "down") {
      runtime.scrollPos -= pxPerFrame;
      if (runtime.scrollPos < 0) runtime.scrollPos = 0;
    } else {
      runtime.scrollPos += pxPerFrame;
      if (runtime.scrollPos > maxScroll) runtime.scrollPos = maxScroll;
    }

    updateTransform();
    updateRoleFromScroll();

    const canContinue =
      (direction === "down" && runtime.scrollPos > 0) ||
      (direction !== "down" && runtime.scrollPos < maxScroll);

    if (canContinue) {
      runtime.frameId = requestAnimationFrame(tick);
    }
  }

  runtime.frameId = requestAnimationFrame(tick);
}

function renderTransportHud() {
  const playText = runtime.isPlaying ? "⏸ PILLANAT ÁLLJ" : "▶ LEJÁTSZÁS";
  const speedText = `${runtime.speed}%`;

  if (!els.transportHud) return;

  els.transportHud.innerHTML = `
    <button class="hud-btn" data-action="start">⏮ Eleje</button>
    <button class="hud-btn" data-action="prev">◀ Előző</button>
    <button class="hud-btn hud-primary" data-action="play">${playText}</button>
    <button class="hud-btn" data-action="next">▶ Következő</button>
    <button class="hud-btn" data-action="end">⏭ Vége</button>
    <button class="hud-btn" data-action="next-item">⏭ Köv. dal</button>
    <button class="hud-btn" data-action="black">⬛ Black</button>
    <span class="hud-meta">Blokk: ${runtime.blockIndex}/${runtime.blockCount}</span>
    <span class="hud-meta">Seb.: ${speedText}</span>
    <input class="hud-range" type="range" min="0" max="200" step="5" value="${runtime.speed}" />
  `;

  els.transportHud.querySelectorAll(".hud-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const action = btn.dataset.action;
      if (!action) return;
      await emit("display:transport", { action });
    });
  });

  const range = els.transportHud.querySelector(".hud-range");
  range?.addEventListener("input", async (event) => {
    const value = Number(event.target.value);
    await emit("display:transport", { action: "speed", value });
  });
}

function renderState(payload) {
  const {
    songTitle,
    role,
    text,
    fullText,
    mode,
    black,
    speed,
    isPlaying,
    showListVisible,
    showListTitles,
    currentItemIndex,
    blocks,
    blockIndex,
    blockCount,
  } = payload;

  const previousKey = runtime.contentKey;
  const previousBlockIndex = runtime.blockIndex;
  const previousMode = runtime.mode;

  runtime.mode = mode || "blocks";
  runtime.speed = Number(speed) || 100;
  runtime.isPlaying = !!isPlaying;
  runtime.blocks = Array.isArray(blocks) ? blocks : [];
  runtime.blockIndex = Number(blockIndex) || 1;
  runtime.blockCount = Number(blockCount) || Math.max(runtime.blocks.length, 1);
  runtime.activeRole = role || "";

  els.songTitle.textContent = songTitle || "";
  applyRoleAppearance(els.role, runtime.mode === "blocks" ? (role || "") : (runtime.activeRole || role || ""));
  renderShowList(showListTitles || [], currentItemIndex || 0, !!showListVisible);
  renderTransportHud();

  clearScrollAnimation();

  if (black) {
    els.content.classList.remove("content-block-mode", "content-scroll-mode");
    els.content.textContent = "";
    runtime.scrollPos = 0;
    updateTransform();
    return;
  }

  if (runtime.mode === "blocks") {
    els.content.classList.remove("content-scroll-mode");
    els.content.classList.add("content-block-mode");
    runtime.contentKey = `block:${songTitle || ""}:${role || ""}:${text || ""}`;
    els.content.textContent = text || "";
    runtime.scrollPos = 0;
    updateTransform();
    applyRoleAppearance(els.role, role || "");
    return;
  }

  els.content.classList.remove("content-block-mode");
  els.content.classList.add("content-scroll-mode");

  const normalizedBlocks = runtime.blocks.length
    ? runtime.blocks.map((block) => ({ role: block.role || "", text: block.text || "" }))
    : [{ role: role || "", text: fullText || text || "" }];

  const nextKey = `scroll:${songTitle || ""}:${normalizedBlocks.map((b) => `${b.role}::${b.text}`).join("||")}`;
  const shouldReposition =
    previousKey !== nextKey ||
    previousBlockIndex !== runtime.blockIndex ||
    previousMode !== runtime.mode;

  runtime.contentKey = nextKey;
  renderScrollBlocks(normalizedBlocks);

  if (shouldReposition) {
    setScrollPosForBlock(Math.max(0, runtime.blockIndex - 1));
  }

  const maxScroll = Math.max(0, els.content.scrollHeight - els.contentWrap.clientHeight);
  if (runtime.mode === "scroll-down" && runtime.scrollPos > maxScroll) {
    runtime.scrollPos = maxScroll;
  }
  if (runtime.mode === "scroll-up" && runtime.scrollPos < 0) {
    runtime.scrollPos = 0;
  }

  updateTransform();
  updateRoleFromScroll();

  if (runtime.isPlaying) {
    startScroll(runtime.mode === "scroll-down" ? "down" : "up");
  }
}

function escapeHtml(value) {
  return String(value || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

listen("display:block", (event) => {
  renderState(event.payload || {});
});

listen("display:overlay", (event) => {
  setOverlay(event.payload?.text || "");
});
